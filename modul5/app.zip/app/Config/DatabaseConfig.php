<?php

namespace app\Config;

class DatabaseConfig
{
  public $host = 'localhost';
  public $user = 'root';
  public $password = '';
  public $database_name = 'modul5';

}
